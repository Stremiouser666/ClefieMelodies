# Zeus Mouse Test 1.2

A standalone Java Android app for testing the Zeus virtual mouse on the JVC Fire TV. This revision fixes three behaviours reported during testing: edge scrolling, pointer-mode retention after clicks, and cursor visibility during video playback.

## Test surface

The app opens to a plain black screen with a circular cursor. Press the remote's **Menu** button to open:

1. **Open National Lottery website** — loads `https://www.national-lottery.co.uk/` in Android System WebView.
2. **Google Search** — opens a search field; the entered query is submitted to Google.
3. **Play Local Video** — opens Android's document picker filtered to video files. Select a video stored on the TV or accessible storage.
4. **Return to Black Screen** — closes the current WebView/video test surface.
5. **Save Log**, **Share Log**, **Clear Log**.

Use the D-pad to move the virtual cursor. D-pad keys are now captured at Activity dispatch level before a focused webpage control can consume them, so clicking a webpage item should not switch the test app into ordinary WebView D-pad navigation. Short OK/Select sends a left-click at the cursor location. Holding OK/Select sends a long press to the underlying content surface.

## Edge scrolling

When the cursor reaches an edge while a direction remains held, the cursor stays at the edge and the WebView viewport scrolls in that direction. This uses the WebView's native scroll position. It applies to the main page viewport; a website with its own independently scrolling nested panel may require a later targeted test. Horizontal scrolling works only where the page has horizontal overflow.

## Video cursor behaviour

The circular cursor is explicitly kept visible and fully opaque during local video playback. It is not automatically hidden when the video is playing or when the media controls disappear. The Android MediaController may still hide its own playback controls after a timeout; that does not hide the Zeus test cursor.

## Diagnostics

The log records device/display metrics, cursor position, remote key events and focus ownership, pointer-mode restoration after clicks, page start/finish and load duration, WebView console messages and main-frame errors, local video preparation/duration/size/info/errors, edge-scroll start/position/stop, and movement frame timing/FPS.

The WebView is Android System WebView supplied by Fire OS. Website compatibility and video codecs depend on the TV's installed WebView/media stack and the website itself. This test app does not bypass website restrictions, DRM, sign-in, age checks or geoblocking.

## Build in CodeAssist

1. Extract the ZIP on the Android phone.
2. Open the `ZeusMouseTest` folder as an existing Android/Gradle project in CodeAssist.
3. Allow Gradle sync. The project uses Android Gradle Plugin 8.3.2, compile SDK 34, Java 17, min SDK 23 and target SDK 28.
4. Build the **debug APK** (`app` > Tasks > build > `assembleDebug`, or CodeAssist's Build APK action).
5. Install the APK over the previous Zeus Mouse Test version. The application ID is unchanged, so the new version should update the existing installation.

## Suggested TV test sequence

1. Black screen: move the cursor in all four directions and save a baseline log.
2. National Lottery: wait for the page to settle, move to the bottom edge and hold DOWN; confirm the page scrolls while the cursor remains at the edge. Repeat for UP and, if the page supports it, LEFT/RIGHT.
3. Click a link or button, then immediately move the cursor with the D-pad. Confirm it remains in pointer mode and does not move webpage focus.
4. Google: run a search, move over results, click one, then test edge scrolling and pointer movement.
5. Local video: choose a representative video file, let it play beyond the media-control timeout, and confirm the circular cursor remains visible and movable.
6. Share the log so scroll movement, pointer focus and frame timing can be checked.

## Notes

- This is a diagnostic test harness, not the Zeus Browser and not a production browser.
- The app intentionally uses the Android System WebView rather than bundling Chromium.
- The local video is opened through Android's Storage Access Framework; no broad storage permission is requested.
- The cursor is drawn as a transparent overlay above the WebView or VideoView. Cursor clicks are forwarded to the active content surface at the cursor coordinates.
